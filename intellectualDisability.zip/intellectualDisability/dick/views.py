from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt


@csrf_exempt
# Create your views here.
def monkeyDick(request):
    theWay = request.method
    if theWay == 'GET':
        return render(request, 'monkeyDick.html')
    else:
        return render(request, 'monkeyDick.html')
